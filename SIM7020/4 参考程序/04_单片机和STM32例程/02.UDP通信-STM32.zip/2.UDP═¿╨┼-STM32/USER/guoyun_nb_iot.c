/*
**�������ڱ���������Ľ��մ���
**
*/
#include <string.h>
#include "guoyun_nb_iot.h"

extern guoyun_nb_iot_rcv_buf_t ring_buf;

static int cmd_res = -1; /* ����ִ�н�� */
static int cmd_num = 0;

static int check_creg_cmd(guoyun_nb_iot_rcv_buf_t *buf, unsigned int b_pos, int *pos)
{
    int ret = RES_INVALID;
    int buf_pos;
    
    buf_pos = (buf->out_ptr + b_pos + 1) % BUFFER_SIZE;
    
    /********ð�ź��浽OK�����\r\n��10���ַ�**************
        +CREG: 0,6

        OK

    ***********************/

    *pos = strlen(" 0,6\r\nOK\r\n");
    if (buf_pos < buf->in_ptr)
    {
        if ((buf->in_ptr - buf_pos) < *pos)
        {
            return RES_NOT_READY;
        }
    }
    else
    {
        
    }
    
    return ret;
}

/*
**�ص�����������Ҫ���ش�����Ľ���λ��,�����ٷ��ص�ʱ��,����ring_buf
*/
rcv_cmd_response_t slave_rcv_cmd[] = 
{
    {"+CREG:", 0, 0, check_creg_cmd, RES_INVALID},
    
};

void init_cmd_respons(void)
{
    int num = 0;
    int i;
    
    num     = sizeof(slave_rcv_cmd) / sizeof(slave_rcv_cmd[0]);
    cmd_num = num;
    for (i = 0; i < num;i++)
    {
        slave_rcv_cmd[i].cmd_len = strlen(slave_rcv_cmd[i].rcv_cmd) + strlen("\r\n");
    }
}

void ring_buf_init(guoyun_nb_iot_rcv_buf_t *buf)
{
    memset((char *)buf, 0, sizeof(buf));
}

int ring_buf_len(guoyun_nb_iot_rcv_buf_t *buf)
{
    if (buf->full)
    {
        return BUFFER_SIZE;
    }
    
    if (buf->in_ptr == buf->out_ptr && buf->full == 0)
    {
        return 0;
    }
    else if (buf->in_ptr > buf->out_ptr)
    {    
        return buf->in_ptr - buf->out_ptr;
    }
    else
    {
        return BUFFER_SIZE - (buf->out_ptr - buf->in_ptr - 1);
    }
}

int ring_buf_find_str(guoyun_nb_iot_rcv_buf_t *buf, char *str)
{
    if (strstr(&buf->buf[buf->out_ptr], str))
    {
        return 0;
    }
    
    return -1;
}

int ring_buf_put_one_char(guoyun_nb_iot_rcv_buf_t *buf, char c)
{
    int pos = 0;
    
    if (buf->full == 1)
    {
        return -1;
    }
    
    buf->buf[buf->in_ptr] = c;
    pos = buf->in_ptr + 1;
    if (pos >= BUFFER_SIZE)
    {
        pos = 0;
    }
    
    if (pos == buf->out_ptr)
    {
        buf->full = 1;
    }
    
    buf->in_ptr = pos;
    
    return 0;
}

int ring_buf_pre_get_one_char(guoyun_nb_iot_rcv_buf_t *buf, char *c, unsigned int pos)
{
    unsigned int read_pos;    
    if (buf->in_ptr == buf->out_ptr && buf->full == 0)
    {
        return -1;
    }
    
    read_pos = pos + buf->out_ptr;
    if (read_pos >= BUFFER_SIZE)
    {
        read_pos = 0;
    }
    
    *c = buf->buf[read_pos];
    
    return 0;
}

void ring_buf_get_one_char_out(guoyun_nb_iot_rcv_buf_t *buf)
{
    
    if (buf->in_ptr == buf->out_ptr && buf->full == 0)
    {
        return;
    }
    
    buf->buf[buf->out_ptr] = '\0';
    buf->out_ptr++;
    if (buf->out_ptr >= BUFFER_SIZE)
    {
        buf->out_ptr = 0;
    }
    
    buf->full = 0; 
}

void ring_buf_move_out_ptr(guoyun_nb_iot_rcv_buf_t *buf, unsigned int pos)
{
    buf->out_ptr = pos;
}

int whether_rcv_cmd(guoyun_nb_iot_rcv_buf_t *buf)
{
    int pos;
    
    if (buf->out_ptr == buf->in_ptr)
    {
        return -1;
    }
    
    pos = buf->out_ptr;
    
    if (buf->out_ptr < buf->in_ptr)
    {
        while (pos <= buf->in_ptr)
        {
            if (buf->buf[pos] == ':')
            {
                return 0;
            }
        }
    }
    else
    {
        while (1)
        {
            if (pos == buf->in_ptr)
            {
                break;
            }
            
            if (buf->buf[pos] == ':')
            {
                return 0;
            }
            pos++;
            if (pos >= BUFFER_SIZE)
            {
                pos = 0;
            }
        }
    }
    
    return -1;
}

void check_and_exec_receive_cmd(void)
{
    int ret = -1;
    int i;
    char c;
    char find_cmd = 0;
    char cmd[15];
    int pos = -1;
    
    if (ring_buf_len(&ring_buf) < 3)
    {
        return;
    }
    
    while(ring_buf_len(&ring_buf) >= 3)
    {
        ret = ring_buf_pre_get_one_char(&ring_buf, &c, 0);
        if (ret != 0)
        {
            return;
        }
        
        if (c != '\r')
        {
            ring_buf_get_one_char_out(&ring_buf);
        }
        else
        {
            ret = ring_buf_pre_get_one_char(&ring_buf, &c, 1);
            if (c != '\n')
            {
                ring_buf_get_one_char_out(&ring_buf);
                if (c != '\r')
                {
                    ring_buf_get_one_char_out(&ring_buf);
                }
            }
            else
            {
                ret = ring_buf_pre_get_one_char(&ring_buf, &c, 2);
                if (c != '+')
                {
                    ring_buf_get_one_char_out(&ring_buf);
                    ring_buf_get_one_char_out(&ring_buf);
                    if (c != '\r')
                    {
                        ring_buf_get_one_char_out(&ring_buf);
                    }
                }
                else
                {
                    ret = whether_rcv_cmd(&ring_buf);
                    if (ret == 0)
                    {
                        find_cmd = 1;
                    }
                }
            }
        }
    }
    
    if (find_cmd == 0)
    {
        return;
    }
    
    memset(cmd, '\0', 15);
    
    i = 0;
    ret = ring_buf_pre_get_one_char(&ring_buf, &c, i);
    while(c != ':' && i < 15)
    {
        cmd[i] = c;
        i++;
        ret = ring_buf_pre_get_one_char(&ring_buf, &c, i);
    }
    
    for (i = 0; i < cmd_num; i++)
    {
        if (strstr(cmd, slave_rcv_cmd[i].rcv_cmd) == 0)
        {
            ret = slave_rcv_cmd[i].deal_rcv_cmd(&ring_buf, slave_rcv_cmd[i].cmd_len, &pos);
            
            //˵�����û�н������
            if (ret == RES_NOT_READY)
            {
                break;
            }
            
            ring_buf_move_out_ptr(&ring_buf, pos);
            
            slave_rcv_cmd[i].ret = ret;
        }
    }
}

/*
** 0:����ִ�гɹ�
**-1:����ִ��ʧ��
**-2:���û��ִ��
*/
void set_rcv_cmd_res(int res)
{
    cmd_res = res;
}

int get_rcv_cmd_res(int res)
{
    return cmd_res;
}
