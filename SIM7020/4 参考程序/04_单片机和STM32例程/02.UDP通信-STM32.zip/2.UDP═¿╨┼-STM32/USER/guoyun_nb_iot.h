#ifndef _GUOYUN_NB_IOT_H
#define _GUOYUN_NB_IOT_H

#define BUFFER_SIZE  2048

typedef enum cur_state{
    
    STA_IDE           = 0x00,
    STA_MSATER_PROC   = 0x01,
    STA_SLAVE_PROC    = 0x02,
    STA_PROC_FINISHED = 0x03,
    
}cur_state_t;

typedef enum cmd_result{
    
    RES_OK        = 0x00,
    RES_ERROR     = -1,
    RES_INVALID   = -2,
    RES_NOT_READY = -3,
    
}cmd_result_t;

typedef struct guoyun_nb_iot_rcv_buf {
    cur_state_t   sta;
    char buf[BUFFER_SIZE];
    unsigned int  in_ptr;
    unsigned int  out_ptr;
    unsigned char full;
}guoyun_nb_iot_rcv_buf_t;

typedef struct rcv_cmd_response{
    
    char *rcv_cmd;
    int  cmd_len;        /* �յ����ַ�������������ȲŽ��бȶ� */
    int  rcv_cmd_pos;    /* ���յ��ı��������ڻ���������ʼλ�� */
    int  (*deal_rcv_cmd)(guoyun_nb_iot_rcv_buf_t *buf, unsigned int b_pos, int *pos);
    int  ret;
}rcv_cmd_response_t;


void init_cmd_respons(void);
void set_rcv_cmd_res(int res);
int get_rcv_cmd_res(int res);
void ring_buf_init(guoyun_nb_iot_rcv_buf_t *buf);
int ring_buf_len(guoyun_nb_iot_rcv_buf_t *buf);
int ring_buf_find_str(guoyun_nb_iot_rcv_buf_t *buf, char *str);
void ring_buf_ptr_out(guoyun_nb_iot_rcv_buf_t *buf);
int ring_buf_put_one_char(guoyun_nb_iot_rcv_buf_t *buf, char c);

#endif
